import { config } from 'dotenv';
config();

import '@/ai/flows/predict-future-sales.ts';